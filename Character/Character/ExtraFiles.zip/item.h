#ifndef ITEM_H
#define ITEM_H

#include <string>

using namespace std;

class Item
{
    public:
        virtual string name() = 0;
        virtual string description() = 0;
    virtual ~Item() { } // CHANGED THIS
};

/*******************************************************************
The following three classes are Portal Gems, required to be in the
character's inventory in order to beat the game
*/
class Ruby : public Item
{
    public:
        string name(){return "Ruby";}
        string description(){return "";}
};

class Sapphire : public Item
{
    public:
        string name(){return "Sapphire";}
        string description(){return "";}
};

class Emerald : public Item
{
    public:
        string name(){return "Emerald";}
        string description(){return "";}
};

/*******************************************************************
The following classes are all single-use consumables
*/
class Potion : public Item
{
    protected:
        //the value that will be used to determine how much the
        //potion heals or buffs
        int value;
    public:
        int getValue(){return value;}
        Potion(int n) : value(n){}
};

//Heals player, increasing their current health to at most the value of
//their max health2
class HealthPotion : public Potion
{
    public:
        string name(){return "Health Potion";}
        string description(){return "";}
        HealthPotion() : Potion(15){};
};

//Permanently increases player's max health
class MaxHealthPotion : public Potion
{
    public:
        string name(){return "Max Health Potion";}
        string description(){return "";}
        MaxHealthPotion() : Potion(5){};
};

//Permanently increases player's strength
class StrengthPotion : public Potion
{
    public:
        string name(){return "Strength Potion";}
        string description(){return "";}
        StrengthPotion() : Potion(1){};
};

//Permanently increases player's intelligence
class IntPotion : public Potion
{
    public:
        string name(){return "Intelligence Potion";}
        string description(){return "";}
        IntPotion() : Potion(1){};
};

//Permanently increases player's luck
class LuckPotion : public Potion
{
    public:
        string name(){return "Luck Potion";}
        string description(){return "";}
        LuckPotion() : Potion(1){};
};

//Instantly kills an enemy
class KillScroll : public Item
{
    public:
        string name(){return "Kill Scroll";}
        string description(){return "";}
};

#endif
