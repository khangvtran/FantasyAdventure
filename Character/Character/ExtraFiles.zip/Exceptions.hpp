/*
 
  Specification file for the Exceptions class.
 
 */

#ifndef Exceptions_hpp
#define Exceptions_hpp

#include <iostream>
#include <cstring>
using namespace std;

class BoundaryError : public range_error
{
public:
    BoundaryError(const char* arg) : range_error(arg) {}
    virtual const char* what() const throw()
    {
        return (range_error::what());
    }
};

#endif
