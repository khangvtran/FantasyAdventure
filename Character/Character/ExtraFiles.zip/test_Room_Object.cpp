#define _CRT_SECURE_NO_WARNINGS

#include <iomanip>
#include <string.h>
#include <stdlib.h> 
#include "RoomObject.h"

/*
using namespace std;
int main() {
	Book book("Book", "You got a book!");
	book.read();
	std::cout << std::endl << std::endl;


	Map map("Map", "A map hanging in the wall. You can check which room have treasure!!!");
	map.check();
	std::cout << std::endl << std::endl;

	Flares flare("Flare", "Using flare to check four adjacent room's object!!!");
	flare.DisplayAdjacentRoomObject();
	std::cout << std::endl << std::endl;


	Fountain fountain("Fountain", "You can drink it to increase he/she health!!!");
	cout << "Increase health: " << fountain.drink();
	std::cout << std::endl << std::endl;


	Treasure treasure("Treasure", "This room has treasure!!!");
	treasure.DisplayWinGameMess();
	std::cout << std::endl << std::endl;


	system("pause");
	return 0;


}*/
