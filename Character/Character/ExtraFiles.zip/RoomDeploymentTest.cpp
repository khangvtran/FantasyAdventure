/*
 
 AdventureGame
 
 Welcome to the phantasy adventure game! In search for riches and personal glory you have arrived at this
 dark and abandoned dungeon full of dragons and other creatures that lurk from around all corners ready to
 attack you and stall your journey for greatness.
 To find the treasure you will have to navigate through a labyrinth and slay monsters.
 Along the way you will find useful hints that will guide you toward the room with the treasure as well as
 maps that will show you your location in relation to the treasure room. You will collect items that
 will help you recover, kill monsters, and move closer to your goal. You have 3 lives.
 Use them wisely!
 
 */
/*
#include <iostream>
#include <cstdlib>
#include "Dungeon.hpp"
#include "Monster.hpp"
using namespace std;

const int ROWS = 3;
const int COLS = 3;

int main()
{
    srand(static_cast<unsigned int>(time(NULL)));
    bool flag = false;
    
    //TEST CASE #1: Create a Dungeon object
    cout << "TEST CASE #1: Create a Dungeon object" << endl;
    Dungeon dungeon(ROWS, COLS);
    
    //TEST CASE #2: Display Dungeon Rooms (ROOM DEPLOYMENT)
    cout << "\nTEST CASE #2: Display Dungeon Rooms" << endl;
    cout << dungeon;
    
    //TEST CASE #3: Test subscript [][] Operator
    cout << "\nTEST #3: Test subscript [][] Operator" << endl;
    cout << dungeon[0][1];
    cout << dungeon[1][2];
    
    //TEST CASE #4: Test checkNorth function
    cout << "\nTEST #4: Test checkNorth Function" << endl;
    cout << boolalpha << dungeon[0][1].checkNorth() << endl;
    cout << boolalpha << dungeon[0][1].checkEast() << endl;
    
    //TEST CASE #5: Test printMap function
    cout << "\nTEST #5: Test printMap function" << endl;
    dungeon.printMap();
    
    //TEST CASE #6: Test Creating Dragon Objects
    cout << "\nTEST #6: Test Creating Dragon Objects" << endl;
    Dragon dragon1;
    cout << "DRAGON NAME: " << dragon1.getName() << endl;
    cout << "DRAGON DESCRIPTION: " << dragon1.getDescription() << endl;
    cout << "DRAGON STRENGTH: " << dragon1.getStrength() << endl;
    cout << "DRAGON HEALTH: " << dragon1.getHealth() << endl;
    cout << "DRAGON LUCK: "  << dragon1.getLuck() << endl;
    cout << "DRAGON ALIVE: " << boolalpha << dragon1.isAlive() << endl;
    cout << "DRAGON VITALITY: " << dragon1.getVitality() << endl;
    cout << "DAMAGE TO CHARACTER: " << dragon1.attack(8, flag) << endl;
    
    //TEST CASE #7: Test Creating Dragon Objects
    cout << "\nTEST #7: Test Creating Dragon Objects" << endl;
    Dragon dragon2;
    cout << "DRAGON NAME: " << dragon2.getName() << endl;
    cout << "DRAGON DESCRIPTION: " << dragon2.getDescription() << endl;
    cout << "DRAGON STRENGTH: " << dragon2.getStrength() << endl;
    cout << "DRAGON HEALTH: " << dragon2.getHealth() << endl;
    cout << "DRAGON LUCK: "  << dragon2.getLuck() << endl;
    cout << "DRAGON ALIVE: " << dragon2.isAlive() << endl;
    cout << "DRAGON VITALITY: " << dragon2.getVitality() << endl;
    cout << "DAMAGE TO CHARACTER: " << dragon2.attack(8, flag) << endl;
    
    //TEST CASE #8: Test Creating Dragon Objects
    cout << "\nTEST #8: Test Creating Dragon Objects" << endl;
    Dragon dragon3;
    cout << "DRAGON NAME: " << dragon3.getName() << endl;
    cout << "DRAGON DESCRIPTION: " << dragon3.getDescription() << endl;
    cout << "DRAGON STRENGTH: " << dragon3.getStrength() << endl;
    cout << "DRAGON HEALTH: " << dragon3.getHealth() << endl;
    cout << "DRAGON LUCK: "  << dragon3.getLuck() << endl;
    cout << "DRAGON ALIVE: " << dragon3.isAlive() << endl;
    cout << "DRAGON VITALITY: " << dragon3.getVitality() << endl;
    cout << "DAMAGE TO CHARACTER: " << dragon3.attack(8, flag) << endl;
    
    //TEST CASE #9: Test Creating Titan Objects
    cout << "\nTEST #9: Test Creating Titan Objects" << endl;
    Titan titan1;
    cout << "TITAN NAME: " << titan1.getName() << endl;
    cout << "TITAN DESCRIPTION: " << titan1.getDescription() << endl;
    cout << "TITAN STRENGTH: " << titan1.getStrength() << endl;
    cout << "TITAN HEALTH: " << titan1.getHealth() << endl;
    cout << "TITAN LUCK: "  << titan1.getLuck() << endl;
    cout << "TITAN ALIVE: " << titan1.isAlive() << endl;
    cout << "TITAN VITALITY: " << titan1.getAgility() << endl;
    cout << "DAMAGE TO CHARACTER: " << titan1.attack(8, flag) << endl;
    
    //TEST CASE #10: Test Creating Titan Objects
    cout << "\nTEST #10: Test Creating Titan Objects" << endl;
    Titan titan2;
    cout << "TITAN NAME: " << titan2.getName() << endl;
    cout << "TITAN DESCRIPTION: " << titan2.getDescription() << endl;
    cout << "TITAN STRENGTH: " << titan2.getStrength() << endl;
    cout << "TITAN HEALTH: " << titan2.getHealth() << endl;
    cout << "TITAN LUCK: "  << titan2.getLuck() << endl;
    cout << "TITAN ALIVE: " << titan2.isAlive() << endl;
    cout << "TITAN VITALITY: " << titan2.getAgility() << endl;
    cout << "DAMAGE TO CHARACTER: " << titan2.attack(8, flag) << endl;
    
    //TEST CASE #11: Test Creating Titan Objects
    cout << "\nTEST #11: Test Creating Titan Objects" << endl;
    Titan titan3;
    cout << "TITAN NAME: " << titan3.getName() << endl;
    cout << "TITAN DESCRIPTION: " << titan3.getDescription() << endl;
    cout << "TITAN STRENGTH: " << titan3.getStrength() << endl;
    cout << "TITAN HEALTH: " << titan3.getHealth() << endl;
    cout << "TITAN LUCK: "  << titan3.getLuck() << endl;
    cout << "TITAN ALIVE: " << titan3.isAlive() << endl;
    cout << "TITAN VITALITY: " << titan3.getAgility() << endl;
    cout << "DAMAGE TO CHARACTER: " << titan3.attack(8, flag) << endl;
    
    //TEST CASE #12: Test Creating DragonBoss Objects
    cout << "\nTEST #12: Test Creating DragonBoss Objects" << endl;
    DragonBoss dragonBoss1;
    cout << "DRAGONBOSS NAME: " << titan3.getName() << endl;
    cout << "DRAGONBOSS DESCRIPTION: " << titan3.getDescription() << endl;
    cout << "DRAGONBOSS STRENGTH: " << titan3.getStrength() << endl;
    cout << "DRAGONBOSS HEALTH: " << titan3.getHealth() << endl;
    cout << "DRAGONBOSS LUCK: "  << titan3.getLuck() << endl;
    cout << "DRAGONBOSS ALIVE: " << titan3.isAlive() << endl;
    cout << "DRAGONBOSS VITALITY: " << titan3.getAgility() << endl;
    cout << "DAMAGE TO CHARACTER: " << titan3.attack(8, flag) << endl;
    
    //TEST CASE #13: Test Getting Room Description
    cout << "\nTEST #13: Test Getting Room Description" << endl;
    for (int i = 0; i < ROWS; i++)
    {
        for (int j = 0; j < COLS; j++)
        {
            cout << dungeon[i][j].getDescription() << endl;
        }
    }

    //TEST CASE #14: Testing Displaying Adjacent Rooms
    cout << "\nTEST #14: Test Display Adjacent Rooms" << endl;
    for (int i = 0; i < ROWS; i++)
    {
        for (int j = 0; j < COLS; j++)
        {
            dungeon.printAdjacentRooms(i,j);
        }
    }
    
    return 0;
}

*/
/*
 
 TEST CASE #1: Create a Dungeon object

TEST CASE #2: Display Dungeon Rooms
row:  0 col:  0 walls:  9 MonsterPtr:                  0x0     RoomObjectPtr:          0x10054f2c0 Items: true
row:  0 col:  1 walls:  3 MonsterPtr:                  0x0     RoomObjectPtr:                  0x0 Items: false
row:  0 col:  2 walls:  5 MonsterPtr:                  0x0     RoomObjectPtr:                  0x0 Items: false
row:  1 col:  0 walls: 12 MonsterPtr:                  0x0     RoomObjectPtr:                  0x0 Items: false
row:  1 col:  1 walls: 13 MonsterPtr:          0x10054cd10     RoomObjectPtr:                  0x0 Items: true
row:  1 col:  2 walls: 12 MonsterPtr:          0x10054c690     RoomObjectPtr:                  0x0 Items: true
row:  2 col:  0 walls: 10 MonsterPtr:                  0x0     RoomObjectPtr:                  0x0 Items: false
row:  2 col:  1 walls:  2 MonsterPtr:                  0x0     RoomObjectPtr:          0x10054f200 Items: true
row:  2 col:  2 walls:  6 MonsterPtr:                  0x0     RoomObjectPtr:                  0x0 Items: false

TEST #3: Test subscript [][] Operator
row:  0 col:  1 walls:  3 MonsterPtr:                  0x0     RoomObjectPtr:                  0x0 Items: false
row:  1 col:  2 walls: 12 MonsterPtr:          0x10054c690     RoomObjectPtr:                  0x0 Items: true

TEST #4: Test checkNorth Function
false
true

TEST #5: Test printMap function
 _ _ _
|  _  |
|  |  |  |
|___|

TEST #6: Test Creating Dragon Objects
DRAGON NAME:
DRAGON DESCRIPTION:
DRAGON STRENGTH: 10
DRAGON HEALTH: 50
DRAGON LUCK: 5
DRAGON ALIVE: true
DRAGON VITALITY: 3
DAMAGE TO CHARACTER: Luckily, he missed this time!
0

TEST #7: Test Creating Dragon Objects
DRAGON NAME:
DRAGON DESCRIPTION:
DRAGON STRENGTH: 3
DRAGON HEALTH: 50
DRAGON LUCK: 1
DRAGON ALIVE: true
DRAGON VITALITY: 1
DAMAGE TO CHARACTER: Luckily, he missed this time!
0

TEST #8: Test Creating Dragon Objects
DRAGON NAME:
DRAGON DESCRIPTION:
DRAGON STRENGTH: 8
DRAGON HEALTH: 50
DRAGON LUCK: 5
DRAGON ALIVE: true
DRAGON VITALITY: 17
DAMAGE TO CHARACTER: Watch out! Fire coming your way!
Luckily, he missed this time!
0

TEST #9: Test Creating Titan Objects
TITAN NAME:
TITAN DESCRIPTION:
TITAN STRENGTH: 1
TITAN HEALTH: 40
TITAN LUCK: 11
TITAN ALIVE: true
TITAN VITALITY: 7
DAMAGE TO CHARACTER: Luckily, he missed this time!
0

TEST #10: Test Creating Titan Objects
TITAN NAME:
TITAN DESCRIPTION:
TITAN STRENGTH: 15
TITAN HEALTH: 40
TITAN LUCK: 10
TITAN ALIVE: true
TITAN VITALITY: 9
DAMAGE TO CHARACTER: Luckily, he missed this time!
0

TEST #11: Test Creating Titan Objects
TITAN NAME:
TITAN DESCRIPTION:
TITAN STRENGTH: 7
TITAN HEALTH: 40
TITAN LUCK: 0
TITAN ALIVE: true
TITAN VITALITY: 19
DAMAGE TO CHARACTER: You just lost a piece of equimpent. You better pick it back up quickly!
Luckily, he missed this time!
0

TEST #12: Test Creating DragonBoss Objects
DRAGONBOSS NAME:
DRAGONBOSS DESCRIPTION:
DRAGONBOSS STRENGTH: 7
DRAGONBOSS HEALTH: 40
DRAGONBOSS LUCK: 0
DRAGONBOSS ALIVE: true
DRAGONBOSS VITALITY: 19
DAMAGE TO CHARACTER: You just lost a piece of equimpent. You better pick it back up quickly!
Luckily, he missed this time!
0

TEST #13: Test Getting Room Description
In this room you find a(n) treasure
You have found your riches! In front of you is a chest full of gold coins, gemstones and other valuables! You have successfully accomplished your mission. Congratulations!
In this room you find a(n) Ruby
In this room you find a(n) Sapphire
In this room you find a(n) Emerald
In this room you find a(n) So you have found the biggest and scariest dragon in this dungeon that guards this place's treasures. Only a few moments separate you from becoming rich and winning the fame and glory of a great warrior you came here for. The only thing you have to do is face this bad-tempered oversized colossus. Remember he can hurl fireballs your way and knock down any of your equipment. Good luck! Become a legend or become dinner!

In this room you find a(n) This gigantic humanlike creature can crush you in no time. If you're not careful, he can knock down your equipment.

In this room you find a(n) Adamantine Dagger
In this room you find a(n) map
You find this large map hanging on the wall. You can use it to check where the gems, monsters, and treaseure are.
In this room you find a(n) Mithril Dagger

TEST #14: Test Display Adjacent Rooms
There is no room NORTH of you.

In the room SOUTH of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger
In the room EAST of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger
There is no room WEST of you.


There is no room NORTH of you.

In the room SOUTH of you there is a(n): So you have found the biggest and scariest dragon in this dungeon that guards this place's treasures. Only a few moments separate you from becoming rich and winning the fame and glory of a great warrior you came here for. The only thing you have to do is face this bad-tempered oversized colossus. Remember he can hurl fireballs your way and knock down any of your equipment. Good luck! Become a legend or become dinner!

In the room EAST of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger
In the room WEST of you there is a(n):  treasure


There is no room NORTH of you.

In the room SOUTH of you there is a(n): This gigantic humanlike creature can crush you in no time. If you're not careful, he can knock down your equipment.

There is no room EAST of you.

In the room WEST of you there is a(n):  Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger

In the room NORTH of you there is a(n): treasure

In the room SOUTH of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger
In the room EAST of you there is a(n): So you have found the biggest and scariest dragon in this dungeon that guards this place's treasures. Only a few moments separate you from becoming rich and winning the fame and glory of a great warrior you came here for. The only thing you have to do is face this bad-tempered oversized colossus. Remember he can hurl fireballs your way and knock down any of your equipment. Good luck! Become a legend or become dinner!

There is no room WEST of you.


In the room NORTH of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger

In the room SOUTH of you there is a(n): map

In the room EAST of you there is a(n): This gigantic humanlike creature can crush you in no time. If you're not careful, he can knock down your equipment.

In the room WEST of you there is a(n):  Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger

In the room NORTH of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger

In the room SOUTH of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger
There is no room EAST of you.

In the room WEST of you there is a(n):  So you have found the biggest and scariest dragon in this dungeon that guards this place's treasures. Only a few moments separate you from becoming rich and winning the fame and glory of a great warrior you came here for. The only thing you have to do is face this bad-tempered oversized colossus. Remember he can hurl fireballs your way and knock down any of your equipment. Good luck! Become a legend or become dinner!


In the room NORTH of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger

There is no room SOUTH of you.

In the room EAST of you there is a(n): map

There is no room WEST of you.


In the room NORTH of you there is a(n): So you have found the biggest and scariest dragon in this dungeon that guards this place's treasures. Only a few moments separate you from becoming rich and winning the fame and glory of a great warrior you came here for. The only thing you have to do is face this bad-tempered oversized colossus. Remember he can hurl fireballs your way and knock down any of your equipment. Good luck! Become a legend or become dinner!

There is no room SOUTH of you.

In the room EAST of you there is a(n): Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger
In the room WEST of you there is a(n):  Health Potion Max Health Potion Strength Potion Intelligence Potion Luck Potion Kill Scroll Iron Helmet Steel Helmet Mithril Helmet Adamantine Helmet Iron Armor Steel Armor Mithril Armor Adamantine Helmet Iron Greaves Steel Greaves Mithril Greaves Adamantine Greaves Iron Sword Steel Sword Mithril Sword Adamantine Sword Iron Dagger Steel Dagger

In the room NORTH of you there is a(n): This gigantic humanlike creature can crush you in no time. If you're not careful, he can knock down your equipment.

There is no room SOUTH of you.

There is no room EAST of you.

In the room WEST of you there is a(n):  map


 */
