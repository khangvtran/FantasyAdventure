//
//  Exceptions.cpp
//  AdventureGame
//
//  Created by Agnieszka on 25.02.18.
//  Copyright © 2018 Agnieszka. All rights reserved.
//

#include "Exceptions.hpp"
